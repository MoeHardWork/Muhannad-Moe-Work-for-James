public class index {
	public static void main(String[]args) {
		System.out.println("test");
		kettle moe = new kettle ("Chrome","Samsung",500);
		System.out.println(moe);
		moe.fillUp(100);
		System.out.println(moe);
		moe.pour(50);
		System.out.println(moe);
		moe.pour(150);
		System.out.println(moe);
		moe.pour(150);
		System.out.println(moe);
		moe.fillUp(100);
		System.out.println(moe);
		moe.fillUp(100);
		System.out.println(moe);
		moe.fillUp(100);
		System.out.println(moe);
		moe.fillUp(1000000);
		System.out.println(moe);
		
		
	}
}
